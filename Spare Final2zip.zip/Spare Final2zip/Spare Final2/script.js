// Function to check if the user is logged in
function checkLoginStatus() {
    const loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser) {
        window.location.href = 'Spare.html'; // Redirect to Spare.html if already logged in
    }
}

// Handle Login
document.getElementById('loginForm')?.addEventListener('submit', function (event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        localStorage.setItem('loggedInUser', username); // Set the logged-in user
        window.location.href = 'Spare.html'; // Redirect to Spare.html after successful login
    } else {
        alert('Invalid username or password'); // Show error message if credentials don't match
    }
});

// Handle Sign Up
document.getElementById('signupForm')?.addEventListener('submit', function (event) {
    event.preventDefault();

    const username = document.getElementById('newUsername').value;
    const password = document.getElementById('newPassword').value;

    if (username && password) {
        // Retrieve existing users or create an empty array if none exist
        const users = JSON.parse(localStorage.getItem('users')) || [];
        // Check if the username already exists
        const existingUser = users.find(user => user.username === username);

        if (existingUser) {
            alert('Username already exists, please choose a different one.');
        } else {
            // Add the new user to the users array
            users.push({ username, password });
            localStorage.setItem('users', JSON.stringify(users));
            alert('Sign-up successful!');
            window.location.href = 'loginpage.html'; // Redirect to login page after successful signup
        }
    } else {
        alert('Please fill in all fields'); // Show error if fields are empty
    }
});

// Function to add item to the cart
function addToCart(itemName, price) {
    // Get the current cart from localStorage (if any)
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Create a new item object
    const item = {
        name: itemName,
        price: price,
        quantity: 1  // Add quantity if needed
    };

    // Check if the item already exists in the cart
    let existingItem = cart.find(item => item.name === itemName);
    if (existingItem) {
        existingItem.quantity += 1;  // Increase quantity if the item already exists
    } else {
        cart.push(item);  // Add new item if it doesn't exist
    }

    // Save the updated cart back to localStorage
    try {
        localStorage.setItem('cart', JSON.stringify(cart));
    } catch (e) {
        console.error("Error saving to localStorage: ", e);
        alert('There was an error adding the item to the cart.');
    }

    // Optionally, show a confirmation or update the UI (e.g., show cart count)
    alert(`${itemName} added to cart!`);

    // Redirect to the cart page after a brief delay
    setTimeout(() => {
        window.location.href = 'cart.html';
    }, 1000);  // Delay of 1 second before redirect
}

// Initialize AOS (Animate on Scroll)
AOS.init({
    offset: 300,
    duration: 1450,
});

// Call the checkLoginStatus function to see if the user is already logged in when the page loads
checkLoginStatus();
